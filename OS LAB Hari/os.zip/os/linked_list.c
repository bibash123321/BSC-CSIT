#include <stdio.h>
#include <stdlib.h>

#define MAX 16

typedef struct Node {
    int start;
    int size;
    int allocated; // 0 = free, 1 = allocated
    struct Node* next;
} Node;

Node* head = NULL;

void initMemory(int n) {
    head = (Node*)malloc(sizeof(Node));
    head->start = 0;
    head->size = n;
    head->allocated = 0;
    head->next = NULL;
}

void display() {
    Node* temp = head;
    printf("\nMemory Blocks:\n");
    while (temp != NULL) {
        printf("[%d - %d] Size:%d %s\n",
               temp->start,
               temp->start + temp->size - 1,
               temp->size,
               temp->allocated ? "Allocated" : "Free");
        temp = temp->next;
    }
}

void allocate(int size) {
    Node* temp = head;
    while (temp != NULL) {
        if (!temp->allocated && temp->size >= size) {
            temp->allocated = 1; // mark whole block as allocated
            printf("Allocated %d blocks from %d to %d\n",
                   size, temp->start, temp->start + size - 1);
            return;
        }
        temp = temp->next;
    }
    printf("Not enough space!\n");
}

int main() {
    int n, size;

    printf("Enter total memory size (<= %d): ", MAX);
    scanf("%d", &n);

    if (n <= 0 || n > MAX) {
        printf("Invalid memory size!\n");
        return 1;
    }

    initMemory(n);
    display();

    printf("Enter process size: ");
    scanf("%d", &size);

    allocate(size);
    display();

    return 0;
}
