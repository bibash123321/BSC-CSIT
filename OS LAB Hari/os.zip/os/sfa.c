#include <stdio.h>

#define MAX_BLOCKS 100

int main() {
    int disk[MAX_BLOCKS] = {0};  // 0 = free, 1 = allocated
    int start, length, i, j, choice;

    printf("Sequential File Allocation Simulation\n");
    do {
        printf("\nEnter starting block (0-%d): ", MAX_BLOCKS - 1);
        scanf("%d", &start);

        printf("Enter length of the file: ");
        scanf("%d", &length);

        // Check if space is available
        int flag = 1;
        for (i = start; i < (start + length); i++) {
            if (i >= MAX_BLOCKS || disk[i] == 1) {
                flag = 0;
                break;
            }
        }

        if (flag == 1) {
            for (i = start; i < (start + length); i++) {
                disk[i] = 1; // Allocate
            }
            printf("File allocated from block %d to %d\n", start, start + length - 1);
        } else {
            printf("File cannot be allocated. Blocks not free or out of range.\n");
        }

        printf("\nDisk status:\n");
        for (j = 0; j < MAX_BLOCKS; j++) {
            printf("%d ", disk[j]);
        }
        printf("\n");

        printf("\nDo you want to allocate another file? (1 = Yes / 0 = No): ");
        scanf("%d", &choice);

    } while (choice == 1);

    return 0;
}
