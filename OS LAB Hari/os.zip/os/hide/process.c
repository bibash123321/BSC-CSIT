#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        exit(1);
    } else if (pid == 0) {
        printf("Child Process: PID = %d, Parent PID = %d\n", getpid(), getppid());
        printf("Child Process is terminating.\n");
        exit(0);
    } else {
        printf("Parent Process: PID = %d, Child PID = %d\n", getpid(), pid);
        wait(NULL);
        printf("Child process terminated. Parent continues.\n");
    }

    return 0;
}
