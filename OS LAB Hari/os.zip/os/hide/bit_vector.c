#include <stdio.h>

#define MAX 16   // total blocks

int bitVector[MAX] = {0}; // initialized to 0

void display(int n) {
    printf("Memory: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", bitVector[i]);
    }
    printf("\n");
}

void allocate(int size, int n) {
    int count = 0, start = -1;

    for (int i = 0; i < n; i++) {
        if (bitVector[i] == 0) {
            if (count == 0) start = i;
            count++;
            if (count == size) {
                for (int j = start; j < start + size; j++)
                    bitVector[j] = 1;
                printf("Allocated %d blocks from %d to %d\n", size, start, start + size - 1);
                return;
            }
        } else count = 0;
    }
    printf("Not enough space!\n");
}

int main() {
    int n, size;
    printf("Enter number of blocks (<= %d): ", MAX);
    scanf("%d", &n);

    if (n <= 0 || n > MAX) {
        printf("Invalid number of blocks!\n");
        return 1;
    }

    display(n);

    printf("Enter process size: ");
    scanf("%d", &size);

    if (size <= 0 || size > n) {
        printf("Invalid process size!\n");
        return 1;
    }

    allocate(size, n);
    display(n);

    return 0;
}
