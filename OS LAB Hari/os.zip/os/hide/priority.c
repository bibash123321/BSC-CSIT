#include <stdio.h>

struct Process {
    int id, arrival, burst, remaining, priority;
    int completion, waiting, turnaround;
    int started;
};

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process proc[n];
    for (int i = 0; i < n; i++) {
        proc[i].id = i + 1;
        printf("Enter arrival time, burst time, priority for process %d: ", proc[i].id);
        scanf("%d %d %d", &proc[i].arrival, &proc[i].burst, &proc[i].priority);
        proc[i].remaining = proc[i].burst;
        proc[i].started = 0;
    }

    int completed = 0, currentTime = 0;
    int prev = -1;

    while (completed < n) {
        int idx = -1;
        int highestPriority = -1;

        for (int i = 0; i < n; i++) {
            if (proc[i].arrival <= currentTime && proc[i].remaining > 0) {
                if (proc[i].priority > highestPriority) {
                    highestPriority = proc[i].priority;
                    idx = i;
                } else if (proc[i].priority == highestPriority && idx != -1) {
                    // If same priority, choose the one with earlier arrival
                    if (proc[i].arrival < proc[idx].arrival) {
                        idx = i;
                    }
                }
            }
        }

        if (idx == -1) {
            currentTime++; // no process ready, increment time
            continue;
        }

        if (!proc[idx].started) {
            proc[idx].started = 1;
        }

        proc[idx].remaining--;
        currentTime++;

        if (proc[idx].remaining == 0) {
            proc[idx].completion = currentTime;
            proc[idx].turnaround = proc[idx].completion - proc[idx].arrival;
            proc[idx].waiting = proc[idx].turnaround - proc[idx].burst;
            completed++;
        }
    }

    printf("\nProcess\tArrival\tBurst\tPriority\tCompletion\tWaiting\tTurnaround\n");
    int totalWaiting = 0, totalTurnaround = 0;
    for (int i = 0; i < n; i++) {
        totalWaiting += proc[i].waiting;
        totalTurnaround += proc[i].turnaround;
        printf("%d\t%d\t%d\t%d\t\t%d\t\t%d\t%d\n",
               proc[i].id, proc[i].arrival, proc[i].burst, proc[i].priority,
               proc[i].completion, proc[i].waiting, proc[i].turnaround);
    }
    printf("\nAverage waiting time = %.2f\n", (float)totalWaiting / n);
    printf("Average turnaround time = %.2f\n", (float)totalTurnaround / n);

    return 0;
}
