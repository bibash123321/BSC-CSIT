#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 100

// Disk block structure
struct Block {
    int allocated;
    int next;
};

int main() {
    struct Block disk[MAX_BLOCKS];
    int start, length, i, j, choice;

    // Initialize disk
    for (i = 0; i < MAX_BLOCKS; i++) {
        disk[i].allocated = 0;
        disk[i].next = -1;
    }

    printf("Linked File Allocation Simulation\n");

    do {
        printf("\nEnter starting block (0-%d): ", MAX_BLOCKS - 1);
        scanf("%d", &start);

        printf("Enter length of file: ");
        scanf("%d", &length);

        if (disk[start].allocated == 1) {
            printf("Starting block already allocated. Try another.\n");
        } else {
            int k = start;
            int flag = 1;

            for (i = 0; i < length; i++) {
                // find a free block
                while (k < MAX_BLOCKS && disk[k].allocated == 1) {
                    k++;
                }
                if (k >= MAX_BLOCKS) {
                    flag = 0;
                    break;
                }

                disk[k].allocated = 1;

                // set pointer to next block if not last
                if (i < length - 1) {
                    int nextBlock = k + 1;
                    while (nextBlock < MAX_BLOCKS && disk[nextBlock].allocated == 1) {
                        nextBlock++;
                    }
                    if (nextBlock >= MAX_BLOCKS) {
                        flag = 0;
                        break;
                    }
                    disk[k].next = nextBlock;
                    k = nextBlock;
                }
            }

            if (flag == 1) {
                printf("File allocated with linked blocks:\n");
                int current = start;
                printf("%d", current);
                while (disk[current].next != -1) {
                    printf(" -> %d", disk[current].next);
                    current = disk[current].next;
                }
                printf("\n");
            } else {
                printf("File cannot be allocated (insufficient space).\n");
            }
        }

        printf("\nDisk status (allocated=1, free=0):\n");
        for (j = 0; j < MAX_BLOCKS; j++) {
            printf("%d ", disk[j].allocated);
        }
        printf("\n");

        printf("\nDo you want to allocate another file? (1=Yes / 0=No): ");
        scanf("%d", &choice);

    } while (choice == 1);

    return 0;
}
