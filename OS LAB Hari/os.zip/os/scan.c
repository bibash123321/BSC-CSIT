#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, head, i, j, size, move, seek = 0;

    printf("SCAN Disk Scheduling Algorithm\n");

    printf("Enter number of requests: ");
    scanf("%d", &n);

    int req[n + 1], order[n + 2];  

    printf("Enter request sequence:\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &req[i]);
    }

    printf("Enter initial head position: ");
    scanf("%d", &head);

    printf("Enter total disk size (e.g., 200): ");
    scanf("%d", &size);

    printf("Enter head movement direction (1=High, 0=Low): ");
    scanf("%d", &move);

    // Add head to request list
    req[n] = head;
    n++;

    // Sort requests
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if (req[i] > req[j]) {
                int temp = req[i];
                req[i] = req[j];
                req[j] = temp;
            }
        }
    }

    // Find head index
    int pos;
    for (i = 0; i < n; i++) {
        if (req[i] == head) {
            pos = i;
            break;
        }
    }

    int k = 0;
    if (move == 1) { // move towards higher end
        for (i = pos; i < n; i++) order[k++] = req[i];
        order[k++] = size - 1; // go to end
        for (i = pos - 1; i >= 0; i--) order[k++] = req[i];
    } else { // move towards lower end
        for (i = pos; i >= 0; i--) order[k++] = req[i];
        order[k++] = 0; // go to start
        for (i = pos + 1; i < n; i++) order[k++] = req[i];
    }

    printf("\nSeek Sequence: ");
    for (i = 0; i < k; i++) {
        printf("%d ", order[i]);
    }

    // Calculate total seek time
    for (i = 0; i < k - 1; i++) {
        seek += abs(order[i + 1] - order[i]);
    }

    printf("\nTotal Seek Time = %d\n", seek);
    printf("Average Seek Time = %.2f\n", (float)seek / (n - 1));

    return 0;
}
