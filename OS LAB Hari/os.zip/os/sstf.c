#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, head, i, j, min, diff, seek = 0, index;
    int completed[100] = {0};  // keeps track of serviced requests

    printf("SSTF Disk Scheduling Algorithm\n");

    printf("Enter number of disk requests: ");
    scanf("%d", &n);

    int req[n];
    printf("Enter the request sequence:\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &req[i]);
    }

    printf("Enter initial head position: ");
    scanf("%d", &head);

    printf("\nSeek Sequence: ");
    for (i = 0; i < n; i++) {
        min = 1e9;
        index = -1;

        // Find the request closest to current head
        for (j = 0; j < n; j++) {
            if (!completed[j]) {
                diff = abs(head - req[j]);
                if (diff < min) {
                    min = diff;
                    index = j;
                }
            }
        }

        completed[index] = 1;
        seek += min;
        head = req[index];

        printf("%d ", head);
    }

    printf("\nTotal Seek Time = %d\n", seek);
    printf("Average Seek Time = %.2f\n", (float)seek / n);

    return 0;
}
