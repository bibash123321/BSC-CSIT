#include <stdio.h>

#define MAX_BLOCKS 100

int main() {
    int disk[MAX_BLOCKS] = {0};  // 0 = free, 1 = allocated
    int indexBlock, length, i, choice;

    printf("Indexed File Allocation Simulation\n");

    do {
        printf("\nEnter index block (0-%d): ", MAX_BLOCKS - 1);
        scanf("%d", &indexBlock);

        if (disk[indexBlock] == 1) {
            printf("Index block already allocated! Choose another.\n");
        } else {
            printf("Enter number of blocks needed for the file: ");
            scanf("%d", &length);

            int blocks[length];
            int flag = 1;

            printf("Enter %d block numbers:\n", length);
            for (i = 0; i < length; i++) {
                scanf("%d", &blocks[i]);
                if (blocks[i] >= MAX_BLOCKS || disk[blocks[i]] == 1 || blocks[i] == indexBlock) {
                    flag = 0;
                }
            }

            if (flag == 1) {
                disk[indexBlock] = 1;
                for (i = 0; i < length; i++) {
                    disk[blocks[i]] = 1;
                }

                printf("File allocated.\n");
                printf("Index block %d points to blocks: ", indexBlock);
                for (i = 0; i < length; i++) {
                    printf("%d ", blocks[i]);
                }
                printf("\n");
            } else {
                printf("File cannot be allocated (invalid or already allocated blocks).\n");
            }
        }

        printf("\nDisk status (1=allocated, 0=free):\n");
        for (i = 0; i < MAX_BLOCKS; i++) {
            printf("%d ", disk[i]);
        }
        printf("\n");

        printf("\nDo you want to allocate another file? (1=Yes / 0=No): ");
        scanf("%d", &choice);

    } while (choice == 1);

    return 0;
}
